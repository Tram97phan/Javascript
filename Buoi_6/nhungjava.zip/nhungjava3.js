
function showMessage() {
    alert('Xin Chao');
}